
import os
import dj_database_url
from dotenv import load_dotenv
from datetime import timedelta
from pathlib import Path

 # Load environment variables from .env file

BASE_DIR = Path(__file__).resolve().parent.parent
CORE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

load_dotenv(os.path.join(BASE_DIR, ".env"))

# Quick-start development settings - unsuitable for production
# See https://docs.djangoproject.com/en/3.0/howto/deployment/checklist/

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = os.getenv("SECRET_KEY")

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = os.getenv("DEBUG") == "True"

ALLOWED_HOSTS = [
    host.strip()
    for host in os.getenv(
        "ALLOWED_HOSTS",
        "127.0.0.1,localhost,api.tickfirst.net,tickfirst.net,"
        "www.tickfirst.net,teak-backend.vercel.app",
    ).split(",")
    if host.strip()
]

# Use project-specific cookie names so another Django app running on a
# different localhost port cannot overwrite the admin form's CSRF cookie.
CSRF_COOKIE_NAME = os.getenv("CSRF_COOKIE_NAME", "tickfirst_csrftoken")
SESSION_COOKIE_NAME = os.getenv("SESSION_COOKIE_NAME", "tickfirst_sessionid")
CSRF_TRUSTED_ORIGINS = [
    origin.strip()
    for origin in os.getenv(
        "CSRF_TRUSTED_ORIGINS",
        "http://localhost:8000,http://127.0.0.1:8000,"
        "https://api.tickfirst.net,https://tickfirst.net,"
        "https://www.tickfirst.net",
    ).split(",")
    if origin.strip()
]

# Application definition
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'cloudinary_storage',
    'django.contrib.staticfiles', # Must be below cloudinary_storage
    'cloudinary',
    'rest_framework',
    'rest_framework.authtoken',
    'rest_framework_simplejwt',
    'rest_framework_simplejwt.token_blacklist',
    'django_filters',
    'corsheaders',
    'accounts',
    'events',
    'orders',
    'admin_dash',
    "drf_spectacular",
]


MIDDLEWARE = [
    'corsheaders.middleware.CorsMiddleware',
    'django.middleware.security.SecurityMiddleware',
    'whitenoise.middleware.WhiteNoiseMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'tick_backend.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [os.path.join(BASE_DIR, 'templates')],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'tick_backend.wsgi.application'


# Database

DATABASES = {
    'default': dj_database_url.config(
        default=os.getenv("DATABASE_URL", "sqlite:///db.sqlite3"),
    )
}

STORAGES = {
    "default": {
        "BACKEND": "cloudinary_storage.storage.MediaCloudinaryStorage",
    },
    "staticfiles": {
        "BACKEND": "whitenoise.storage.CompressedStaticFilesStorage",
    },
}


# Password validation
# https://docs.djangoproject.com/en/3.0/ref/settings/#auth-password-validators

AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]

# AUTH_USER_MODEL = 'accounts.User'
AUTH_USER_MODEL = 'accounts.CustomUser'

REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': (
        'rest_framework_simplejwt.authentication.JWTAuthentication',
    ),
    'DEFAULT_FILTER_BACKENDS': ['django_filters.rest_framework.DjangoFilterBackend'],
    "DEFAULT_SCHEMA_CLASS": "drf_spectacular.openapi.AutoSchema",
}


SPECTACULAR_SETTINGS = {
    "TITLE": "Event Ticketing API",

    "DESCRIPTION": """
        Event Management API.

        Features:
        - Authentication
        - Event creation
        - Ticket ordering
        - Admin analytics
    """,
    "VERSION": "1.0.0",

    "SERVE_INCLUDE_SCHEMA": False,

    "COMPONENT_SPLIT_REQUEST": True,

    "SECURITY": [
        {"BearerAuth": []}
    ],

    "COMPONENTS": {
        "securitySchemes": {
            "BearerAuth": {
                "type": "http",
                "scheme": "bearer",
                "bearerFormat": "JWT"
            }
        }
    },

    "SWAGGER_UI_SETTINGS": {
        "deepLinking": True,
        "persistAuthorization": True,
    }
}

# Internationalization
# https://docs.djangoproject.com/en/3.0/topics/i18n/

LANGUAGE_CODE = 'en-us'

TIME_ZONE = 'UTC'

USE_I18N = True

USE_L10N = True

USE_TZ = True

TIME_INPUT_FORMATS = [
    '%H:%M:%S',    # '14:30:59'
    '%H:%M',       # '14:30'
    '%I:%M %p',    # '02:30 PM' (adds support for AM/PM)
]

CORS_ALLOWED_ORIGINS = [
    "http://localhost:5173",
    "http://localhost:5174",
    "http://localhost:5175",
    "http://localhost:5176",
    "http://localhost:5177",
    "https://tickfirst.net",
    "https://www.tickfirst.net"
]

CORS_ALLOW_CREDENTIALS = True

CORS_ALLOW_HEADERS = [
    "accept",
    "accept-encoding",
    "authorization",
    "content-type",
    "dnt",
    "origin",
    "user-agent",
    "x-csrftoken",
    "x-requested-with",
    # Add any other custom headers your frontend might be using
]


FRONTEND_URL = os.getenv(
    "FRONTEND_URL",
    "http://localhost:5173" if DEBUG else "https://tickfirst.net",
)
PASSWORD_RESET_FRONTEND_URL = os.getenv(
    "PASSWORD_RESET_FRONTEND_URL",
    "http://localhost:5173" if DEBUG else "https://tickfirst.net",
)

PAYSTACK_SECRET_KEY=os.getenv("PAYSTACK_SECRET_KEY")
PAYSTACK_CALLBACK_URL=f"{FRONTEND_URL}/payment-success"



SIMPLE_JWT = {
    'ACCESS_TOKEN_LIFETIME': timedelta(minutes=60),
    'REFRESH_TOKEN_LIFETIME': timedelta(days=15),
    # Other settings...
}


EMAIL_BACKEND = os.getenv(
    "EMAIL_BACKEND",
    "glob_utils.brevo_backend.BrevoEmailBackend",
)
BREVO_API_KEY = os.getenv("BREVO_API_KEY", "")
BREVO_API_TIMEOUT = int(os.getenv("BREVO_API_TIMEOUT", "30"))
BREVO_SENDER_NAME = os.getenv("BREVO_SENDER_NAME", "TickFirst")
DEFAULT_FROM_EMAIL = os.getenv(
    "DEFAULT_FROM_EMAIL",
    f"{BREVO_SENDER_NAME} <hello@tickfirst.net>",
)
CONTACT_EMAIL = os.getenv("CONTACT_EMAIL", "hello@tickfirst.net")
TICKET_PLATFORM_FEE_PERCENTAGE = os.getenv("TICKET_PLATFORM_FEE_PERCENTAGE", "5.00")

# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/3.0/howto/static-files/


# Add WhiteNoise to MIDDLEWARE (after SecurityMiddleware)
STATIC_URL = '/static/'
STATIC_ROOT = os.path.join(BASE_DIR, 'staticfiles')
STATICFILES_STORAGE = 'whitenoise.storage.CompressedStaticFilesStorage'

MEDIA_ROOT = os.path.join(BASE_DIR, "media")
MEDIA_URL = "/media/"




CLOUDINARY_STORAGE = {
    'CLOUD_NAME':'ducy4bo9m',
    'API_KEY':os.getenv("CLOUDSTORE_API_KEY"),
    'API_SECRET': os.getenv("CLOUDSTORE_API_SECRET")
}

# Set the default file storage
#if not DEBUG: # If on Vercel/Production
DEFAULT_FILE_STORAGE = 'cloudinary_storage.storage.MediaCloudinaryStorage'
